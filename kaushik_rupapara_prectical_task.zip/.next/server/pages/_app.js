/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./Layout/layout.js":
/*!**************************!*\
  !*** ./Layout/layout.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/header */ \"./components/header.js\");\n\n\nconst Layout = (props)=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: ``,\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_header__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\Layout\\\\layout.js\",\n                lineNumber: 6,\n                columnNumber: 13\n            }, undefined),\n            props.children,\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"footer\", {}, void 0, false, {\n                fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\Layout\\\\layout.js\",\n                lineNumber: 8,\n                columnNumber: 13\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\Layout\\\\layout.js\",\n        lineNumber: 5,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9MYXlvdXQvbGF5b3V0LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQXdDO0FBRXhDLE1BQU1DLFNBQVMsQ0FBQ0M7SUFDWixxQkFDSSw4REFBQ0M7UUFBSUMsV0FBVyxDQUFDLENBQUM7OzBCQUNkLDhEQUFDSiwwREFBTUE7Ozs7O1lBQ05FLE1BQU1HLFFBQVE7MEJBQ2YsOERBQUNDOzs7Ozs7Ozs7OztBQWFiO0FBRUEsaUVBQWVMLE1BQU1BLEVBQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9lY29tbWFyY2VfZGVtby8uL0xheW91dC9sYXlvdXQuanM/NDRhNSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSGVhZGVyIGZyb20gXCJAL2NvbXBvbmVudHMvaGVhZGVyXCJcclxuXHJcbmNvbnN0IExheW91dCA9IChwcm9wcykgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGB9PlxyXG4gICAgICAgICAgICA8SGVhZGVyIC8+XHJcbiAgICAgICAgICAgIHtwcm9wcy5jaGlsZHJlbn1cclxuICAgICAgICAgICAgPGZvb3Rlcj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogZ3RtIHNjcmlwdCAqL31cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogPG5vc2NyaXB0XHJcbiAgICAgICAgICAgICAgICAgICAgZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgX19odG1sOiBgPGlmcmFtZSBzcmM9XCJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbS9ucy5odG1sP2lkPXt7SUR9fVwiXHJcbiAgICAgICAgICAgIGhlaWdodD1cIjBcIiB3aWR0aD1cIjBcIiBzdHlsZT1cImRpc3BsYXk6bm9uZTt2aXNpYmlsaXR5OmhpZGRlblwiPjwvaWZyYW1lPmAsXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIC8+ICovfVxyXG4gICAgICAgICAgICA8L2Zvb3Rlcj5cclxuICAgICAgICA8L2RpdiA+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IExheW91dCJdLCJuYW1lcyI6WyJIZWFkZXIiLCJMYXlvdXQiLCJwcm9wcyIsImRpdiIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwiZm9vdGVyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./Layout/layout.js\n");

/***/ }),

/***/ "./components/header.js":
/*!******************************!*\
  !*** ./components/header.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ \"./node_modules/next/image.js\");\n/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Header = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"sticky top-0 z-[10] drop-shadow-lg py-[5px] w-[100%] px-[10px] bg-[#f2f2f2] sm:py-[10px] sm:px-[10px]\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"flex justify-end bg-slate-400 p-[5px]\",\n                children: [\n                    \" \",\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                        className: \"p-[5px] border rounded\",\n                        children: \"Login\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\components\\\\header.js\",\n                        lineNumber: 7,\n                        columnNumber: 69\n                    }, undefined)\n                ]\n            }, void 0, true, {\n                fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\components\\\\header.js\",\n                lineNumber: 7,\n                columnNumber: 13\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"flex justify-between items-center w-[100%] max-lg:flex-wrap lg:px-[55px]\",\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        className: \"max-lg:order-1 flex w-[50%] lg:w-[auto] gap-2\",\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            className: \"text-[50px]\",\n                            children: \"Logo\"\n                        }, void 0, false, {\n                            fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\components\\\\header.js\",\n                            lineNumber: 10,\n                            columnNumber: 21\n                        }, undefined)\n                    }, void 0, false, {\n                        fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\components\\\\header.js\",\n                        lineNumber: 9,\n                        columnNumber: 17\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        className: \"flex justify-between items-center max-lg:order-2\",\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            onClick: ()=>{},\n                            className: \"relative flex flex-col justify-center items-center w-[30px] lg:w-[50px] cursor-pointer\",\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {\n                                    loading: \"eager\",\n                                    priority: true,\n                                    src: \"https://cdn.perrian.com/static/website/cart.svg\",\n                                    width: 100,\n                                    height: 100,\n                                    alt: \"cart\",\n                                    className: \"w-[27px] h-[27px] lg:w-[26px] lg:h-[26px]\"\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\components\\\\header.js\",\n                                    lineNumber: 18,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                                    className: \"text-[12px] hidden lg:block text-mainColor\",\n                                    children: \"Cart\"\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\components\\\\header.js\",\n                                    lineNumber: 19,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                                    className: \"w-[10px] h-[10px] max-lg:top-[-24%] max-lg:right-[-14%] sm:w-[21px] sm:h-[21px] leading-[18px] text-center absolute top-[-10%] border border-mainColor right-[0%] shadow-2xl bg-white text-[15px] max-lg:text-[12px] sm:text-[13px] rounded-full flex justify-center items-center p-[8px] text-[#2c2c2c]\",\n                                    children: 0\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\components\\\\header.js\",\n                                    lineNumber: 20,\n                                    columnNumber: 25\n                                }, undefined)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\components\\\\header.js\",\n                            lineNumber: 17,\n                            columnNumber: 21\n                        }, undefined)\n                    }, void 0, false, {\n                        fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\components\\\\header.js\",\n                        lineNumber: 15,\n                        columnNumber: 17\n                    }, undefined)\n                ]\n            }, void 0, true, {\n                fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\components\\\\header.js\",\n                lineNumber: 8,\n                columnNumber: 13\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\components\\\\header.js\",\n        lineNumber: 6,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL2hlYWRlci5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBOEI7QUFFOUIsTUFBTUMsU0FBUztJQUVYLHFCQUNJLDhEQUFDQztRQUFJQyxXQUFVOzswQkFDWCw4REFBQ0Q7Z0JBQUlDLFdBQVU7O29CQUF3QztrQ0FBQyw4REFBQ0M7d0JBQU9ELFdBQVU7a0NBQXlCOzs7Ozs7Ozs7Ozs7MEJBQ25HLDhEQUFDRDtnQkFBSUMsV0FBVTs7a0NBQ1gsOERBQUNEO3dCQUFJQyxXQUFVO2tDQUNYLDRFQUFDRDs0QkFBSUMsV0FBVTtzQ0FBYzs7Ozs7Ozs7Ozs7a0NBS2pDLDhEQUFDRDt3QkFBSUMsV0FBVTtrQ0FFWCw0RUFBQ0Q7NEJBQUlHLFNBQVMsS0FBUTs0QkFBR0YsV0FBVTs7OENBQy9CLDhEQUFDSCxtREFBS0E7b0NBQUNNLFNBQVE7b0NBQVFDLFVBQVU7b0NBQU1DLEtBQUs7b0NBQW1EQyxPQUFPO29DQUFLQyxRQUFRO29DQUFLQyxLQUFJO29DQUFPUixXQUFVOzs7Ozs7OENBQzdJLDhEQUFDUztvQ0FBRVQsV0FBVTs4Q0FBNkM7Ozs7Ozs4Q0FDMUQsOERBQUNVO29DQUFLVixXQUFVOzhDQUE0Uzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFNcFY7QUFDQSxpRUFBZUYsTUFBTUEsRUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL2Vjb21tYXJjZV9kZW1vLy4vY29tcG9uZW50cy9oZWFkZXIuanM/YzA5OCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSW1hZ2UgZnJvbSBcIm5leHQvaW1hZ2VcIlxyXG5cclxuY29uc3QgSGVhZGVyID0gKCkgPT4ge1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J3N0aWNreSB0b3AtMCB6LVsxMF0gZHJvcC1zaGFkb3ctbGcgcHktWzVweF0gdy1bMTAwJV0gcHgtWzEwcHhdIGJnLVsjZjJmMmYyXSBzbTpweS1bMTBweF0gc206cHgtWzEwcHhdJz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGJnLXNsYXRlLTQwMCBwLVs1cHhdXCI+IDxidXR0b24gY2xhc3NOYW1lPVwicC1bNXB4XSBib3JkZXIgcm91bmRlZFwiPkxvZ2luPC9idXR0b24+PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdy1bMTAwJV0gbWF4LWxnOmZsZXgtd3JhcCBsZzpweC1bNTVweF0nPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J21heC1sZzpvcmRlci0xXHRmbGV4IHctWzUwJV0gbGc6dy1bYXV0b10gZ2FwLTInPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bNTBweF1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTG9nb1xyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2ZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYXgtbGc6b3JkZXItMic+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgb25DbGljaz17KCkgPT4geyB9fSBjbGFzc05hbWU9J3JlbGF0aXZlIGZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHctWzMwcHhdIGxnOnctWzUwcHhdIGN1cnNvci1wb2ludGVyJz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlIGxvYWRpbmc9XCJlYWdlclwiIHByaW9yaXR5PXt0cnVlfSBzcmM9e1wiaHR0cHM6Ly9jZG4ucGVycmlhbi5jb20vc3RhdGljL3dlYnNpdGUvY2FydC5zdmdcIn0gd2lkdGg9ezEwMH0gaGVpZ2h0PXsxMDB9IGFsdD0nY2FydCcgY2xhc3NOYW1lPVwidy1bMjdweF0gaC1bMjdweF0gbGc6dy1bMjZweF0gbGc6aC1bMjZweF1cIj48L0ltYWdlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSBoaWRkZW4gbGc6YmxvY2sgdGV4dC1tYWluQ29sb3JcIj5DYXJ0PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J3ctWzEwcHhdIGgtWzEwcHhdIG1heC1sZzp0b3AtWy0yNCVdIG1heC1sZzpyaWdodC1bLTE0JV0gc206dy1bMjFweF0gc206aC1bMjFweF0gbGVhZGluZy1bMThweF0gdGV4dC1jZW50ZXIgYWJzb2x1dGUgdG9wLVstMTAlXSBib3JkZXIgYm9yZGVyLW1haW5Db2xvciByaWdodC1bMCVdIHNoYWRvdy0yeGwgYmctd2hpdGUgdGV4dC1bMTVweF0gbWF4LWxnOnRleHQtWzEycHhdIHNtOnRleHQtWzEzcHhdIHJvdW5kZWQtZnVsbCBmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBwLVs4cHhdIHRleHQtWyMyYzJjMmNdJz57MH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXYgPlxyXG4gICAgICAgIDwvZGl2ID5cclxuICAgIClcclxufVxyXG5leHBvcnQgZGVmYXVsdCBIZWFkZXIiXSwibmFtZXMiOlsiSW1hZ2UiLCJIZWFkZXIiLCJkaXYiLCJjbGFzc05hbWUiLCJidXR0b24iLCJvbkNsaWNrIiwibG9hZGluZyIsInByaW9yaXR5Iiwic3JjIiwid2lkdGgiLCJoZWlnaHQiLCJhbHQiLCJwIiwic3BhbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/header.js\n");

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Layout_layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/Layout/layout */ \"./Layout/layout.js\");\n/* harmony import */ var _redux_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/redux/store */ \"./redux/store.js\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-redux */ \"react-redux\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_redux_store__WEBPACK_IMPORTED_MODULE_2__, react_redux__WEBPACK_IMPORTED_MODULE_4__]);\n([_redux_store__WEBPACK_IMPORTED_MODULE_2__, react_redux__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_redux__WEBPACK_IMPORTED_MODULE_4__.Provider, {\n        store: _redux_store__WEBPACK_IMPORTED_MODULE_2__.store,\n        children: [\n            \" \",\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Layout_layout__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n                children: [\n                    \" \",\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                        ...pageProps\n                    }, void 0, false, {\n                        fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\pages\\\\_app.js\",\n                        lineNumber: 7,\n                        columnNumber: 44\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\pages\\\\_app.js\",\n                lineNumber: 7,\n                columnNumber: 35\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\interview\\\\dynamic_dreanz\\\\pages\\\\_app.js\",\n        lineNumber: 7,\n        columnNumber: 10\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFxQztBQUNDO0FBQ1I7QUFDUztBQUV4QixTQUFTRyxJQUFJLEVBQUVDLFNBQVMsRUFBRUMsU0FBUyxFQUFFO0lBQ2xELHFCQUFPLDhEQUFDSCxpREFBUUE7UUFBQ0QsT0FBT0EsK0NBQUtBOztZQUFFOzBCQUFDLDhEQUFDRCxzREFBTUE7O29CQUFDO2tDQUFDLDhEQUFDSTt3QkFBVyxHQUFHQyxTQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDbkUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9lY29tbWFyY2VfZGVtby8uL3BhZ2VzL19hcHAuanM/ZTBhZCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTGF5b3V0IGZyb20gXCJAL0xheW91dC9sYXlvdXRcIjtcbmltcG9ydCB7IHN0b3JlIH0gZnJvbSBcIkAvcmVkdXgvc3RvcmVcIjtcbmltcG9ydCBcIkAvc3R5bGVzL2dsb2JhbHMuY3NzXCI7XG5pbXBvcnQgeyBQcm92aWRlciB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9KSB7XG4gIHJldHVybiA8UHJvdmlkZXIgc3RvcmU9e3N0b3JlfT4gPExheW91dD4gPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPjwvTGF5b3V0PjwvUHJvdmlkZXI+O1xufVxuIl0sIm5hbWVzIjpbIkxheW91dCIsInN0b3JlIiwiUHJvdmlkZXIiLCJBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./redux/rootReducer.js":
/*!******************************!*\
  !*** ./redux/rootReducer.js ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _slices_productSlice__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./slices/productSlice */ \"./redux/slices/productSlice.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_slices_productSlice__WEBPACK_IMPORTED_MODULE_0__]);\n_slices_productSlice__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\nconst rootReducer = {\n    listofProducts: _slices_productSlice__WEBPACK_IMPORTED_MODULE_0__[\"default\"]\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (rootReducer);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9yZWR1eC9yb290UmVkdWNlci5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFnRDtBQUVoRCxNQUFNQyxjQUFjO0lBQ2hCQyxnQkFBZ0JGLDREQUFZQTtBQUNoQztBQUVBLGlFQUFlQyxXQUFXQSxFQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZWNvbW1hcmNlX2RlbW8vLi9yZWR1eC9yb290UmVkdWNlci5qcz9mMzBhIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBwcm9kdWN0U2xpY2UgZnJvbSBcIi4vc2xpY2VzL3Byb2R1Y3RTbGljZVwiXHJcblxyXG5jb25zdCByb290UmVkdWNlciA9IHtcclxuICAgIGxpc3RvZlByb2R1Y3RzOiBwcm9kdWN0U2xpY2UsXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IHJvb3RSZWR1Y2VyIl0sIm5hbWVzIjpbInByb2R1Y3RTbGljZSIsInJvb3RSZWR1Y2VyIiwibGlzdG9mUHJvZHVjdHMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./redux/rootReducer.js\n");

/***/ }),

/***/ "./redux/slices/productSlice.js":
/*!**************************************!*\
  !*** ./redux/slices/productSlice.js ***!
  \**************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   SingleProductData: () => (/* binding */ SingleProductData),\n/* harmony export */   categoryListUpdate: () => (/* binding */ categoryListUpdate),\n/* harmony export */   categorysPeoductData: () => (/* binding */ categorysPeoductData),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   productSlice: () => (/* binding */ productSlice)\n/* harmony export */ });\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ \"@reduxjs/toolkit\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__]);\n_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\nconst productSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({\n    name: \"listOfProduct\",\n    initialState: {\n        singleProductData: [],\n        categoryList: [],\n        categorysPeoductDataList: {}\n    },\n    reducers: {\n        SingleProductData: (state, action)=>{\n            state.singleProductData = action.payload;\n        },\n        categoryListUpdate: (state, action)=>{\n            state.categoryList = action.payload;\n        },\n        categorysPeoductData: (state, action)=>{\n            state.categorysPeoductDataList = action.payload;\n        }\n    }\n});\nconst { SingleProductData, categoryListUpdate, categorysPeoductData } = productSlice.actions;\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (productSlice.reducer);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9yZWR1eC9zbGljZXMvcHJvZHVjdFNsaWNlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUErQztBQUV4QyxNQUFNQyxlQUFlRCw2REFBV0EsQ0FBQztJQUNwQ0UsTUFBTTtJQUNOQyxjQUFjO1FBQ1ZDLG1CQUFtQixFQUFFO1FBQ3JCQyxjQUFjLEVBQUU7UUFDaEJDLDBCQUEwQixDQUFDO0lBQy9CO0lBQ0FDLFVBQVU7UUFDTkMsbUJBQW1CLENBQUNDLE9BQU9DO1lBQ3ZCRCxNQUFNTCxpQkFBaUIsR0FBR00sT0FBT0MsT0FBTztRQUM1QztRQUNBQyxvQkFBb0IsQ0FBQ0gsT0FBT0M7WUFDeEJELE1BQU1KLFlBQVksR0FBR0ssT0FBT0MsT0FBTztRQUN2QztRQUNBRSxzQkFBc0IsQ0FBQ0osT0FBT0M7WUFDMUJELE1BQU1ILHdCQUF3QixHQUFHSSxPQUFPQyxPQUFPO1FBQ25EO0lBQ0o7QUFDSixHQUFFO0FBQ0ssTUFBTSxFQUFFSCxpQkFBaUIsRUFBRUksa0JBQWtCLEVBQUVDLG9CQUFvQixFQUFFLEdBQUdaLGFBQWFhLE9BQU87QUFDbkcsaUVBQWViLGFBQWFjLE9BQU8iLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9lY29tbWFyY2VfZGVtby8uL3JlZHV4L3NsaWNlcy9wcm9kdWN0U2xpY2UuanM/MzhjMyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVTbGljZSB9IGZyb20gXCJAcmVkdXhqcy90b29sa2l0XCI7XHJcblxyXG5leHBvcnQgY29uc3QgcHJvZHVjdFNsaWNlID0gY3JlYXRlU2xpY2Uoe1xyXG4gICAgbmFtZTogJ2xpc3RPZlByb2R1Y3QnLFxyXG4gICAgaW5pdGlhbFN0YXRlOiB7XHJcbiAgICAgICAgc2luZ2xlUHJvZHVjdERhdGE6IFtdLFxyXG4gICAgICAgIGNhdGVnb3J5TGlzdDogW10sXHJcbiAgICAgICAgY2F0ZWdvcnlzUGVvZHVjdERhdGFMaXN0OiB7fSxcclxuICAgIH0sXHJcbiAgICByZWR1Y2Vyczoge1xyXG4gICAgICAgIFNpbmdsZVByb2R1Y3REYXRhOiAoc3RhdGUsIGFjdGlvbikgPT4ge1xyXG4gICAgICAgICAgICBzdGF0ZS5zaW5nbGVQcm9kdWN0RGF0YSA9IGFjdGlvbi5wYXlsb2FkXHJcbiAgICAgICAgfSxcclxuICAgICAgICBjYXRlZ29yeUxpc3RVcGRhdGU6IChzdGF0ZSwgYWN0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgIHN0YXRlLmNhdGVnb3J5TGlzdCA9IGFjdGlvbi5wYXlsb2FkXHJcbiAgICAgICAgfSxcclxuICAgICAgICBjYXRlZ29yeXNQZW9kdWN0RGF0YTogKHN0YXRlLCBhY3Rpb24pID0+IHtcclxuICAgICAgICAgICAgc3RhdGUuY2F0ZWdvcnlzUGVvZHVjdERhdGFMaXN0ID0gYWN0aW9uLnBheWxvYWRcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0pXHJcbmV4cG9ydCBjb25zdCB7IFNpbmdsZVByb2R1Y3REYXRhLCBjYXRlZ29yeUxpc3RVcGRhdGUsIGNhdGVnb3J5c1Blb2R1Y3REYXRhIH0gPSBwcm9kdWN0U2xpY2UuYWN0aW9uc1xyXG5leHBvcnQgZGVmYXVsdCBwcm9kdWN0U2xpY2UucmVkdWNlciJdLCJuYW1lcyI6WyJjcmVhdGVTbGljZSIsInByb2R1Y3RTbGljZSIsIm5hbWUiLCJpbml0aWFsU3RhdGUiLCJzaW5nbGVQcm9kdWN0RGF0YSIsImNhdGVnb3J5TGlzdCIsImNhdGVnb3J5c1Blb2R1Y3REYXRhTGlzdCIsInJlZHVjZXJzIiwiU2luZ2xlUHJvZHVjdERhdGEiLCJzdGF0ZSIsImFjdGlvbiIsInBheWxvYWQiLCJjYXRlZ29yeUxpc3RVcGRhdGUiLCJjYXRlZ29yeXNQZW9kdWN0RGF0YSIsImFjdGlvbnMiLCJyZWR1Y2VyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./redux/slices/productSlice.js\n");

/***/ }),

/***/ "./redux/store.js":
/*!************************!*\
  !*** ./redux/store.js ***!
  \************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   store: () => (/* binding */ store)\n/* harmony export */ });\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ \"@reduxjs/toolkit\");\n/* harmony import */ var _rootReducer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./rootReducer */ \"./redux/rootReducer.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__, _rootReducer__WEBPACK_IMPORTED_MODULE_1__]);\n([_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__, _rootReducer__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\nconst store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({\n    reducer: _rootReducer__WEBPACK_IMPORTED_MODULE_1__[\"default\"]\n});\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9yZWR1eC9zdG9yZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBa0Q7QUFDVjtBQUVqQyxNQUFNRSxRQUFRRixnRUFBY0EsQ0FBQztJQUNoQ0csU0FBU0Ysb0RBQVdBO0FBQ3hCLEdBQUUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9lY29tbWFyY2VfZGVtby8uL3JlZHV4L3N0b3JlLmpzPzM1NDkiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY29uZmlndXJlU3RvcmUgfSBmcm9tIFwiQHJlZHV4anMvdG9vbGtpdFwiO1xyXG5pbXBvcnQgcm9vdFJlZHVjZXIgZnJvbSBcIi4vcm9vdFJlZHVjZXJcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBzdG9yZSA9IGNvbmZpZ3VyZVN0b3JlKHtcclxuICAgIHJlZHVjZXI6IHJvb3RSZWR1Y2VyXHJcbn0pIl0sIm5hbWVzIjpbImNvbmZpZ3VyZVN0b3JlIiwicm9vdFJlZHVjZXIiLCJzdG9yZSIsInJlZHVjZXIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./redux/store.js\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "@reduxjs/toolkit":
/*!***********************************!*\
  !*** external "@reduxjs/toolkit" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = import("@reduxjs/toolkit");;

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = import("react-redux");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc"], () => (__webpack_exec__("./pages/_app.js")));
module.exports = __webpack_exports__;

})();