import productSlice from "./slices/productSlice"

const rootReducer = {
    listofProducts: productSlice,
}

export default rootReducer